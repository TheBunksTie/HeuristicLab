<CorrectnessSpecificationSection>

[TestFixture, Timeout(1000), SingleThreaded, NonParallelizable]
public class TestClass {

[Test]
public void test1 ()  {  
		var count = Syllables.Count("a".ToCharArray()); 
		Assert.That(count, Is.EqualTo(1));
    }
    [Test]
 public void test10 ()  {
        var count = Syllables.Count ("snow white 123 ><".ToCharArray());
        Assert.That(count, Is.EqualTo(3));
    }
    [Test]
 public void test2 ()  {
       var count = Syllables.Count("i o".ToCharArray());
        Assert.That(count, Is.EqualTo(2));
    }
    [Test]
 public void test3 ()  {
       var count = Syllables.Count("mnhd".ToCharArray());
		Assert.That(count, Is.EqualTo(0));
    }
    [Test]
 public void test4 ()  {
       var count = Syllables.Count("hello world".ToCharArray());
        Assert.That(count, Is.EqualTo(3));
    }
    [Test]
 public void test5 ()  {
        var count = Syllables.Count("aeiou".ToCharArray());
		Assert.That(count, Is.EqualTo(5));
    }
    [Test]
 public void test6 ()  {
      var count = Syllables.Count("seasons greetings!".ToCharArray());
		Assert.That(count, Is.EqualTo(6));
    }
    [Test]
 public void test7 ()  {
       var count = Syllables.Count ("which witch is which?".ToCharArray());
        Assert.That(count, Is.EqualTo(4));
    }
    [Test]
 public void test8 ()  {
       var count = Syllables.Count("!@#$%^,".ToCharArray());
        Assert.That(count, Is.EqualTo(0));
    }
    [Test]
 public void test9 ()  {
        var count = Syllables.Count ("123zdh".ToCharArray());
        Assert.That(count, Is.EqualTo(0));
    }
	
	 [Test]
 public void test11 ()  {
        var count = Syllables.Count ("khd".ToCharArray());
        Assert.That(count, Is.EqualTo(0));
    }
    [Test]
 public void test12 ()  {
        var count = Syllables.Count ("aeiouy".ToCharArray());
        Assert.That(count, Is.EqualTo(6));
    }
    [Test]
 public void test13 ()  {
		 var count = Syllables.Count ("here and there".ToCharArray());	
        Assert.That(count, Is.EqualTo(5));
    }
    [Test]
 public void test14 ()  {
        var count = Syllables.Count ("bbbbbbb a".ToCharArray());
        Assert.That(count, Is.EqualTo(1));
    }
    [Test]
 public void test15 ()  {
       var count = Syllables.Count("9876543210".ToCharArray());
       Assert.That(count, Is.EqualTo(0));
    }
    [Test]
 public void test16 ()  {
        var count = Syllables.Count ("1 a 2 e 3 $#@ u".ToCharArray());
        Assert.That(count, Is.EqualTo(3));
    }	
}

<ProductionCodeSection>

class IntObj {
    public int value;
    
	public IntObj () {
    } 
	public IntObj (int i) {
        value = i;
    }
}

class FloatObj {
    public float value;
    public FloatObj () {
    } public FloatObj (float i) {
        value = i;
    }
}

class LongObj {
    public long value;
    public LongObj () {
    } public LongObj (long i) {
        value = i;
    }
}

class DoubleObj {
    public double value;
    public DoubleObj () {
    } public DoubleObj (double i) {
        value = i;
    }
}

class CharObj {
    public char value;
    public CharObj () {
    } public CharObj (char i) {
        value = i;
    }
}

public static class Syllables {

    public static int Count (char[] args) {	
        return calc (args);
    }

    public static int MAX = 20;
	
    public static int calc (char[] args) {
        
		var input = new char[MAX];
		
        var i = new IntObj (); 
		var s = new IntObj ();  
		var len = new IntObj ();
       
        input = Enumerable.ToArray (args);
        
		len.value = input.Length;
        s.value = 0;
        
		for (i.value = 0; i.value < len.value; i.value++) {
            switch (input[i.value]) {
            case 'a':
                s.value++;
                break;
            case 'e':
                s.value++;
                break;
            case 'i':
                s.value++;
                break;
            case 'o':
                s.value++;
                break;
            case 'u':
                s.value++;
                break;
            case 'y':
                s.value++;
                break;
            default:
                break;
            }
        }
		
        return s.value;
    }
}
