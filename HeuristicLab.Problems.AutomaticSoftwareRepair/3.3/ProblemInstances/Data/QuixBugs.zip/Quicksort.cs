//<PassingTestsSection>
Test_0, Test_2, Test_3, Test_4, Test_5, Test_6, Test_7, Test_8, Test_9, Test_10, Test_11, Test_12,

//<FailingTestsSection>
Test_1

//<BestKnownQualitySection>
22

//<CorrectnessSpecificationSection>

  [TestFixture, Timeout (100), SingleThreaded, NonParallelizable]
  public class QUICKSORT_TEST {
    [Test]
    public void Test_0 () {
      var result = QUICKSORT.quicksort (new List<int> { 1, 2, 6, 72, 7, 33, 4 });
      Assert.That (result, Is.EqualTo (new List<int> { 1, 2, 4, 6, 7, 33, 72 }));
    }

    [Test]
    public void Test_1 () {
      var result = QUICKSORT.quicksort (new List<int> { 3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5, 8, 9, 7, 9, 3 });
      Assert.That (result, Is.EqualTo (new List<int> { 1, 1, 2, 3, 3, 3, 4, 5, 5, 5, 6, 7, 8, 9, 9, 9 }));
    }

    [Test]
    public void Test_2 () {
      var result = QUICKSORT.quicksort (new List<int> { 5, 4, 3, 2, 1 });
      Assert.That (result, Is.EqualTo (new List<int> { 1, 2, 3, 4, 5 }));
    }

    [Test]
    public void Test_3 () {
      var result = QUICKSORT.quicksort (new List<int> { 5, 4, 3, 1, 2 });
      Assert.That (result, Is.EqualTo (new List<int> { 1, 2, 3, 4, 5 }));
    }

    [Test]
    public void Test_4 () {
      var result = QUICKSORT.quicksort (new List<int> { 8, 1, 14, 9, 15, 5, 4, 3, 7, 17, 11, 18, 2, 12, 16, 13, 6, 10 });
      Assert.That (result, Is.EqualTo (new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 }));
    }

    [Test]
    public void Test_5 () {
      var result = QUICKSORT.quicksort (new List<int> { 9, 4, 5, 2, 17, 14, 10, 6, 15, 8, 12, 13, 16, 3, 1, 7, 11 });
      Assert.That (result, Is.EqualTo (new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17 }));
    }

    [Test]
    public void Test_6 () {
      var result = QUICKSORT.quicksort (new List<int> { 13, 14, 7, 16, 9, 5, 24, 21, 19, 17, 12, 10, 1, 15, 23, 25, 11, 3, 2, 6, 22, 8, 20, 4, 18 });
      Assert.That (result, Is.EqualTo (new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25 }));
    }

    [Test]
    public void Test_7 () {
      var result = QUICKSORT.quicksort (new List<int> { 8, 5, 15, 7, 9, 14, 11, 12, 10, 6, 2, 4, 13, 1, 3 });
      Assert.That (result, Is.EqualTo (new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 }));
    }

    [Test]
    public void Test_8 () {
      var result = QUICKSORT.quicksort (new List<int> { 4, 3, 7, 6, 5, 2, 1 });
      Assert.That (result, Is.EqualTo (new List<int> { 1, 2, 3, 4, 5, 6, 7 }));
    }

    [Test]
    public void Test_9 () {
      var result = QUICKSORT.quicksort (new List<int> { 4, 3, 1, 5, 2 });
      Assert.That (result, Is.EqualTo (new List<int> { 1, 2, 3, 4, 5 }));
    }

    [Test]
    public void Test_10 () {
      var result = QUICKSORT.quicksort (new List<int> { 5, 4, 2, 3, 6, 7, 1 });
      Assert.That (result, Is.EqualTo (new List<int> { 1, 2, 3, 4, 5, 6, 7 }));
    }

    [Test]
    public void Test_11 () {
      var result = QUICKSORT.quicksort (new List<int> { 10, 16, 6, 1, 14, 19, 15, 2, 9, 4, 18, 17, 12, 3, 11, 8, 13, 5, 7 });
      Assert.That (result, Is.EqualTo (new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19 }));
    }

    [Test]
    public void Test_12 () {
      var result = QUICKSORT.quicksort (new List<int> {10, 16, 6, 1, 14, 19, 15, 2, 9, 4, 18 });
      Assert.That (result, Is.EqualTo (new List<int> { 1, 2, 4, 6, 9, 10, 14, 15, 16, 18, 19 }));
    }
  }

//<ProductionCodeSection>

/**
 *
 * @author derricklin
 */
  public class QUICKSORT {
    public static List<int> quicksort(List<int> arr) {
      if (arr.Count == 0) {
        return new List<int>();
      }

      int pivot = arr[0];
      List<int> lesser = new List<int>();
      List<int> greater = new List<int>();

      foreach (int x in arr.GetRange(1, arr.Count - 1)) {
        if (x < pivot) {
          lesser.Add(x);
        } else if (x > pivot) {
          greater.Add(x);
        }
      }
      List<int> middle = new List<int>();
      middle.Add(pivot);
      lesser = quicksort(lesser);
      greater = quicksort(greater);
      middle.AddRange(greater);
      lesser.AddRange(middle);
      return lesser;

    }
  }


//<CorrectSolutionSection>  

/**
 *
 * @author derricklin
 */
  public class QUICKSORT {
    public static List<int> quicksort(List<int> arr) {
      if (arr.Count == 0) {
        return new List<int>();
      }

      int pivot = arr[0];
      List<int> lesser = new List<int>();
      List<int> greater = new List<int>();

      foreach (int x in arr.GetRange(1, arr.Count - 1)) {
        if (x < pivot) {
          lesser.Add(x);
        } else if (x >= pivot) {
          greater.Add(x);
        }
      }
      List<int> middle = new List<int>();
      middle.Add(pivot);
      lesser = quicksort(lesser);
      greater = quicksort(greater);
      middle.AddRange(greater);
      lesser.AddRange(middle);
      return lesser;

    }
  }