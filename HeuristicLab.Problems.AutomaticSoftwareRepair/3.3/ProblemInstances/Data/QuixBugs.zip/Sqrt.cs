//<PassingTestsSection>
Test_0

//<FailingTestsSection>
Test_1, Test_2, Test_3, Test_4, Test_5, Test_6

//<BestKnownQualitySection>
61

//<CorrectnessSpecificationSection>

 [TestFixture, Timeout (50), SingleThreaded, NonParallelizable]
  public class SQRT_TEST {
    [Test]
    public void Test_0() {
      var result = SQRT.sqrt (2, 0.01);
      Assert.That(result, Is.EqualTo(1.4166666666666665).Within(0.01));
    }
   
  [Test]
  public void Test_1() {
    var result = SQRT.sqrt (2, 0.5);
    Assert.That(result, Is.EqualTo(1.5).Within(0.5));
  }

  [Test]
  public void Test_2() {
    var result = SQRT.sqrt (2, 0.3);
    Assert.That(result, Is.EqualTo(1.5).Within(0.3));
  }

  [Test]
  public void Test_3() {
    var result = SQRT.sqrt (4, 0.2);
    Assert.That(result, Is.EqualTo(2.0).Within(0.2));
  }

  [Test]
  public void Test_4() {
    var result = SQRT.sqrt (27, 0.01);
    Assert.That(result, Is.EqualTo(5.196164639727311).Within(0.01));
    }

  [Test]
  public void Test_5() {
    var result = SQRT.sqrt (33, 0.05);
    Assert.That(result, Is.EqualTo(5.744627526262464).Within(0.05));
  }

  [Test]
  public void Test_6() {
    var result = SQRT.sqrt (170, 0.03);
    Assert.That(result, Is.EqualTo(13.038404876679632).Within(0.03));
  }
}

//<ProductionCodeSection>

 /**
 *
 * @author derricklin
 */
  public class SQRT {
    public static double sqrt(double x, double epsilon) {
      double approx = x / 2f;
      while (Math.Abs(x-approx) > epsilon) {
        approx = 0.5f * (approx + x / approx);
      }
      return approx;
    }
  }


//<CorrectSolutionSection>  

 /**
 *
 * @author derricklin
 */
  public class SQRT {
    public static double sqrt(double x, double epsilon) {
      double approx = x / 2f;
      while (Math.Abs(x-approx*approx) > epsilon) {
        approx = 0.5f * (approx + x / approx);
      }
      return approx;
    }
  }
