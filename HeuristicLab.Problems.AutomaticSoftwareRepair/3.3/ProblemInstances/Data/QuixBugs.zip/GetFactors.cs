//<PassingTestsSection>
Test_0

//<FailingTestsSection>
Test_1, Test_2, Test_3, Test_4, Test_5, Test_6, Test_7, Test_8, Test_9, Test_10 

//<BestKnownQualitySection>
101

//<CorrectnessSpecificationSection>

 [TestFixture, Timeout (50), SingleThreaded, NonParallelizable]
  public class GET_FACTORS_TEST {

    [Test]
    public void Test_0 () {
      var result = GET_FACTORS.get_factors (1);
      Assert.That (result, Is.Empty);
    }

    [Test]
    public void Test_1 () {
      var result = GET_FACTORS.get_factors (100);
      Assert.That (result, Is.EqualTo (new List<int> { 2, 2, 5, 5 }));
    }

    [Test]
    public void Test_2 () {
      var result = GET_FACTORS.get_factors (101);
      Assert.That (result, Is.EqualTo (new List<int> { 101 }));
    }

    [Test]
    public void Test_3 () {
      var result = GET_FACTORS.get_factors (104);
      Assert.That (result, Is.EqualTo (new List<int> { 2, 2, 2, 13 }));
    }

    [Test]
    public void Test_4 () {
      var result = GET_FACTORS.get_factors (2);
      Assert.That (result, Is.EqualTo (new List<int> { 2 }));
    }

    [Test]
    public void Test_5 () {
      var result = GET_FACTORS.get_factors (3);
      Assert.That (result, Is.EqualTo (new List<int> { 3 }));
    }

    [Test]
    public void Test_6 () {
      var result = GET_FACTORS.get_factors (17);
      Assert.That (result, Is.EqualTo (new List<int> { 17 }));
    }

    [Test]
    public void Test_7 () {
      var result = GET_FACTORS.get_factors (63);
      Assert.That (result, Is.EqualTo (new List<int> { 3, 3, 7 }));
    }

    [Test]
    public void Test_8 () {
      var result = GET_FACTORS.get_factors (74);
      Assert.That (result, Is.EqualTo (new List<int> { 2, 37 }));
    }

    [Test]
    public void Test_9 () {
      var result = GET_FACTORS.get_factors (73);
      Assert.That (result, Is.EqualTo (new List<int> { 73 }));
    }

    [Test]
    public void Test_10 () {
      var result = GET_FACTORS.get_factors (9837);
      Assert.That (result, Is.EqualTo (new List<int> { 3, 3, 1093 }));
    }
  }
  
//<ProductionCodeSection>

  /**
 *
 * @author derricklin
 */
  public class GET_FACTORS {
    public static List<int> get_factors (int n) {
      if (n == 1) {
        return new List<int>();
      }

      int max = (int) (Math.Sqrt (n) + 1.0);
      for (int i = 2; i < max; i++) {
        if (n % i == 0) {
          List<int> prepend = new List<int> (0);
          prepend.Add (i);
          prepend.AddRange (get_factors (n / i));
          return prepend;
        }
      }

      return new List<int>();
    }
  }
//<CorrectSolutionSection>  

  /**
 *
 * @author derricklin
 */
  public class GET_FACTORS {
    public static List<int> get_factors (int n) {
      if (n == 1) {
        return new List<int>();
      }

      int max = (int) (Math.Sqrt (n) + 1.0);
      for (int i = 2; i < max; i++) {
        if (n % i == 0) {
          List<int> prepend = new List<int> (0);
          prepend.Add (i);
          prepend.AddRange (get_factors (n / i));
          return prepend;
        }
      }

      return new List<int>() { n };
    }
  }