//<PassingTestsSection>
Test_0, Test_1

//<FailingTestsSection>
Test_2

//<BestKnownQualitySection>
12

//<CorrectnessSpecificationSection>

 [TestFixture, Timeout (50), SingleThreaded, NonParallelizable]
  public class IS_VALID_PARENTHESIZATION_TEST {
    [Test]
    public void Test_0 () {
      var result = IS_VALID_PARENTHESIZATION.is_valid_parenthesization ("((()()))()");
      Assert.That (result, Is.True);
    }

    [Test]
    public void Test_1 () {
      var result = IS_VALID_PARENTHESIZATION.is_valid_parenthesization (")()(");
      Assert.That (result, Is.False);
    }

    [Test]
    public void Test_2 () {
      var result = IS_VALID_PARENTHESIZATION.is_valid_parenthesization ("((");
      Assert.That (result, Is.False);
    }
  }

//<ProductionCodeSection>

  /**
 *
 * @author derricklin
 */
  public class IS_VALID_PARENTHESIZATION {
    public static Boolean is_valid_parenthesization (String parens) {
      int depth = 0;
      for (int i = 0; i < parens.Length; i++) {
        char paren = parens[i];
        if (paren.Equals ('(')) {
          depth++;
        } else {
          depth--;
          if (depth < 0) {
            return false;
          }
        }
      }

      return true;
    }
  }

//<CorrectSolutionSection>  

 /**
 *
 * @author derricklin
 */
  public class IS_VALID_PARENTHESIZATION {
    public static Boolean is_valid_parenthesization (String parens) {
      int depth = 0;
      for (int i = 0; i < parens.Length; i++) {
        char paren = parens[i];
        if (paren.Equals ('(')) {
          depth++;
        } else {
          depth--;
          if (depth < 0) {
            return false;
          }
        }
      }

      return depth==0;
    }
  }