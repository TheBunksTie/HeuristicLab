//<PassingTestsSection>
Test_2, Test_3, Test_4

//<FailingTestsSection>
Test_0, Test_1, Test_5, Test_6 

//<BestKnownQualitySection>
43

//<CorrectnessSpecificationSection>

[TestFixture, Timeout (1000), SingleThreaded, NonParallelizable]
public class KTH_TEST {
    [Test]
    public void Test_0() {
      var result = KTH.kth (new List<int> { 1, 2, 3, 4, 5, 6, 7 }, 4);
      Assert.That (result, Is.EqualTo (5));
    }

    [Test]
    public void Test_1() {
      var result = KTH.kth (new List<int> { 3, 6, 7, 1, 6, 3, 8, 9 }, 5);
      Assert.That (result, Is.EqualTo (7));
    }

    [Test]
    public void Test_2() {
      var result = KTH.kth (new List<int> {3,6,7,1,6,3,8,9 }, 2);
      Assert.That (result, Is.EqualTo (3));
    }

    [Test]
    public void Test_3() {
      var result = KTH.kth (new List<int> { 2, 6, 8, 3, 5, 7 }, 0);
      Assert.That (result, Is.EqualTo (2));
    }

    [Test]
    public void Test_4() {
        var result = KTH.kth (new List<int> { 34, 25, 7, 1, 9 }, 4);
      Assert.That (result, Is.EqualTo (34));
    }

    [Test]
    public void Test_5() {
      var result = KTH.kth (new List<int> { 45, 2, 6, 8, 42, 90, 322 }, 1);
      Assert.That (result, Is.EqualTo (6));
    }

    [Test]
    public void Test_6() {
      var result = KTH.kth (new List<int> { 45, 2, 6, 8, 42, 90, 322 }, 6);
      Assert.That (result, Is.EqualTo (322));
    }
}

//<ProductionCodeSection>
/**
 *
 * @author derricklin
 */
  public class KTH {
    public static int kth(List<int> arr, int k) {
      int pivot = arr[0];
      List<int> below, above;
      below = new List<int>(arr.Count);
      above = new List<int>(arr.Count);
      foreach (int x in arr) {
        if (x < pivot) {
          below.Add(x);
        } else if (x > pivot) {
          above.Add(x);
        }
      }

      int num_less = below.Count;
      int num_lessoreq = arr.Count - above.Count;
      if (k < num_less) {
        return kth(below, k);
      } else if (k >= num_lessoreq) {
        return kth(above, k);
      } else {
        return pivot;
      }
    }
  }

//<CorrectSolutionSection>  
 /**
 *
 * @author derricklin
 */
  public class KTH {
    public static int kth(List<int> arr, int k) {
      int pivot = arr[0];
      List<int> below, above;
      below = new List<int>(arr.Count);
      above = new List<int>(arr.Count);
      foreach (int x in arr) {
        if (x < pivot) {
          below.Add(x);
        } else if (x > pivot) {
          above.Add(x);
        }
      }

      int num_less = below.Count;
      int num_lessoreq = arr.Count - above.Count;
      if (k < num_less) {
        return kth(below, k);
      } else if (k >= num_lessoreq) {
        return kth(above, k-num_lessoreq);
      } else {
        return pivot;
      }
    }
  }