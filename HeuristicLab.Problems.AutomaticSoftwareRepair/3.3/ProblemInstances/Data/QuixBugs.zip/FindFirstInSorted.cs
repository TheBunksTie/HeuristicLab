//<PassingTestsSection>
Test_0, Test_3, Test_5, Test_6

//<FailingTestsSection>
Test_1, Test_2, Test_3 

//<BestKnownQualitySection>
34

//<CorrectnessSpecificationSection>

 [TestFixture, Timeout (3000), SingleThreaded, NonParallelizable]
  public class FIND_FIRST_IN_SORTED_TEST {
    [Test]
    public void Test_0() {
      int result = FIND_FIRST_IN_SORTED.find_first_in_sorted (new int[] { 3, 4, 5, 5, 5, 5, 6 }, (int) 5);

      Assert.That (result, Is.EqualTo (2));
    }

  [Test]
  public void Test_1() {
    int result = FIND_FIRST_IN_SORTED.find_first_in_sorted (new int[] { 3, 4, 5, 5, 5, 5, 6 }, (int) 7);
    Assert.That (result, Is.EqualTo (-1));
  }

  [Test]
  public void Test_2() {
    int result = FIND_FIRST_IN_SORTED.find_first_in_sorted (new int[] { 3, 4, 5, 5, 5, 5, 6 }, (int) 2);
    Assert.That (result, Is.EqualTo (-1));
  }

  [Test]
  public void Test_3() {
    int result = FIND_FIRST_IN_SORTED.find_first_in_sorted (new int[] { 3, 6, 7, 9, 9, 10, 14, 27 }, (int) 14);
    Assert.That (result, Is.EqualTo (6));
  }

  [Test]
  public void Test_4() {
    int result = FIND_FIRST_IN_SORTED.find_first_in_sorted (new int[] { 0, 1, 6, 8, 13, 14, 67, 128 }, (int) 80);
    Assert.That (result, Is.EqualTo (-1));
  }

  [Test]
  public void Test_5() {
    int result = FIND_FIRST_IN_SORTED.find_first_in_sorted (new int[] { 0, 1, 6, 8, 13, 14, 67, 128 }, (int) 67);
    Assert.That (result, Is.EqualTo (6));
  }

  [Test]
  public void Test_6() {
    int result = FIND_FIRST_IN_SORTED.find_first_in_sorted (new int[] { 0, 1, 6, 8, 13, 14, 67, 128 }, (int) 128);
    Assert.That (result, Is.EqualTo (7));
  }
}

//<ProductionCodeSection>

  /**
 *
 * @author derricklin
 */
  public class FIND_FIRST_IN_SORTED {

    public static int find_first_in_sorted(int[] arr, int x) {
      int lo = 0;
      int hi = arr.Length;

      while (lo <= hi) { //solution: lo < hi
        int mid = (lo + hi) / 2; // check if this is floor division

        if (x == arr[mid] && (mid == 0 || x != arr[mid-1])) {
          return mid;
        } else if (x <= arr[mid]) {
          hi = mid;
        } else {
          lo = mid + 1;
        }
      }

      return -1;
    }

  }

//<CorrectSolutionSection>  

  /**
 *
 * @author derricklin
 */
  public class FIND_FIRST_IN_SORTED {

    public static int find_first_in_sorted(int[] arr, int x) {
      int lo = 0;
      int hi = arr.Length;

      while (lo < hi) { 
        int mid = (lo + hi) / 2; // check if this is floor division

        if (x == arr[mid] && (mid == 0 || x != arr[mid-1])) {
          return mid;
        } else if (x <= arr[mid]) {
          hi = mid;
        } else {
          lo = mid + 1;
        }
      }

      return -1;
    }

  }
