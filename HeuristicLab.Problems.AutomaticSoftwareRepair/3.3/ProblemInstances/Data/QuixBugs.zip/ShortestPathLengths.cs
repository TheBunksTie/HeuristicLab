//<PassingTestsSection>
-

//<FailingTestsSection>
Test_0, Test_1, Test_2, Test_3,

//<BestKnownQualitySection>
40

//<CorrectnessSpecificationSection>

[TestFixture, Timeout (1000), SingleThreaded, NonParallelizable]
public class SHORTEST_PATH_LENGTHS_TEST {

    // Case 1: Basic graph input.
	[Test]
	public void Test_0() {
		Dictionary<List<int>, int> graph = new Dictionary<List<int>, int>();
		graph.Add(new List<int>(new List<int> {0, 2}), 3);
		graph.Add(new List<int>(new List<int> {0, 5}), 5);
		graph.Add(new List<int>(new List<int> {2, 1}), -2);
		graph.Add(new List<int>(new List<int> {2, 3}), 7);
		graph.Add(new List<int>(new List<int> {2, 4}), 4);
		graph.Add(new List<int>(new List<int> {3, 4}), -5);
		graph.Add(new List<int>(new List<int> {4, 5}), -1);
		Dictionary<List<int>, int> length_by_path = SHORTEST_PATH_LENGTHS.shortest_path_lengths(6, graph);

    foreach (List<int> edge in length_by_path.Keys) {
			if(edge[0]==3&&edge[1]==3) {
          //Correct (3,3) 0  and bad (3,3) -10
			  Assert.That(length_by_path[edge], Is.EqualTo(0));
			}		
		}
	}

	// Case 2: Linear graph input.
	[Test]
	public void Test_1() {
		Dictionary<List<int>, int> graph2 = new Dictionary<List<int>, int>();
		graph2.Add(new List<int>(new List<int> {0, 1}), 3);
		graph2.Add(new List<int>(new List<int> {1, 2}), 5);
		graph2.Add(new List<int>(new List<int> {2, 3}), -2);
		graph2.Add(new List<int>(new List<int> {3, 4}), 7);

		Dictionary<List<int>, int> length_by_path = SHORTEST_PATH_LENGTHS.shortest_path_lengths(5, graph2);

	  foreach (List<int> edge in length_by_path.Keys) {
	    if(edge[0]==1&&edge[1]==4) {
	      //Correct (1,4) 10  and bad (1,4) inf
	      Assert.That(length_by_path[edge], Is.EqualTo(10));
	    }	
		}		
	}

	// Case 3: Disconnected graphs input.
	[Test]
	public void Test_2() {
		Dictionary<List<int>, int> graph3 = new Dictionary<List<int>, int>();
		graph3.Add(new List<int>(new List<int> {0, 1}), 3);
		graph3.Add(new List<int>(new List<int> {2, 3}), 5);

	  Dictionary<List<int>, int> length_by_path = SHORTEST_PATH_LENGTHS.shortest_path_lengths(4, graph3);
	  foreach (List<int> edge in length_by_path.Keys) {
	    if(edge[0]==1&&edge[1]==0) {
	      //Correct (1,0) inf  and bad (1,0) 3
	      Assert.That(length_by_path[edge], Is.EqualTo(99999));
	    }	
	  }
	}

    [Test]
    // Case 4: Strongly connected graph input.
    public void Test_3 () {
      Dictionary<List<int>, int> graph4 = new Dictionary<List<int>, int>();
      graph4.Add (new List<int> (new List<int> { 0, 1 }), 3);
      graph4.Add (new List<int> (new List<int> { 1, 2 }), 5);
      graph4.Add (new List<int> (new List<int> { 2, 0 }), -1);

      var length_by_path = SHORTEST_PATH_LENGTHS.shortest_path_lengths (3, graph4);

      foreach (List<int> edge in length_by_path.Keys) {
        if (edge[0] == 2 && edge[1] == 1) {
          //Correct (2,1) 2  and bad (2,1) 1
          Assert.That (length_by_path[edge], Is.EqualTo (2));
        }
      }
    }
  }

//<ProductionCodeSection>
  /**
   *
   * @author Angela Chen
   */
  public class SHORTEST_PATH_LENGTHS {
    // Define Infinite as a large enough value. This value will be used
    // for vertices not connected to each other
    const int INF = 99999;
    public static Dictionary<List<int>,int> shortest_path_lengths(int numNodes, Dictionary<List<int>,int> length_by_edge) {
      Dictionary<List<int>,int> length_by_path = new  Dictionary<List<int>,int>();
      for (int i = 0; i < numNodes; i++) {
        for (int j =0; j < numNodes; j++) {
          List<int> edge = new List<int>(new List<int> {i,j});
          if (i == j) {
            length_by_path.Add(edge, 0);
          }
          else if (length_by_edge.ContainsKey(edge) ) {
            length_by_path.Add(edge, length_by_edge[edge]);
          } else {
            length_by_path.Add(edge, INF);
            //solution: return length_by_path;
          }
        }
      }
      for (int k = 0; k < numNodes; k++) {
        for (int i = 0; i < numNodes; i++) {
          for (int j = 0; j < numNodes; j++) {
            int update_length = Math.Min(length_by_path[new List<int> {i,j}], length_by_path[new List<int> {i,k}] + length_by_path[new List<int> {j,k}]);
            length_by_path.Add(new List<int>{i,j}, update_length);
          }
        }
      }
      return length_by_path;
    }
  }

//<CorrectSolutionSection>  
  /**
   *
   * @author Angela Chen
   */
  public class SHORTEST_PATH_LENGTHS {
    // Define Infinite as a large enough value. This value will be used
    // for vertices not connected to each other
    const int INF = 99999;
    public static Dictionary<List<int>,int> shortest_path_lengths(int numNodes, Dictionary<List<int>,int> length_by_edge) {
      Dictionary<List<int>,int> length_by_path = new  Dictionary<List<int>,int>();
      for (int i = 0; i < numNodes; i++) {
        for (int j =0; j < numNodes; j++) {
          List<int> edge = new List<int>(new List<int> {i,j});
          if (i == j) {
            length_by_path.Add(edge, 0);
          }
          else if (length_by_edge.ContainsKey(edge) ) {
            length_by_path.Add(edge, length_by_edge[edge]);
          } else {
            length_by_path.Add(edge, INF);
            return length_by_path;
          }
        }
      }
      for (int k = 0; k < numNodes; k++) {
        for (int i = 0; i < numNodes; i++) {
          for (int j = 0; j < numNodes; j++) {
            int update_length = Math.Min(length_by_path[new List<int> {i,j}], length_by_path[new List<int> {i,k}] + length_by_path[new List<int> {k,j}]);
            length_by_path.Add(new List<int>{i,j}, update_length);
          }
        }
      }
      return length_by_path;
    }
  }
  