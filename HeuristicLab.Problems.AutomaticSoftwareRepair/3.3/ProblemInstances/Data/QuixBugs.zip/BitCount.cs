//<PassingTestsSection>
-

//<FailingTestsSection>
Test_0, Test_1, Test_2, Test_3, Test_4, Test_5, Test_6, Test_7, Test_8,

//<BestKnownQualitySection>
90

//<CorrectnessSpecificationSection>

[TestFixture, Timeout (50), SingleThreaded, NonParallelizable]
public class BITCOUNT_TEST {
  [Test]
  public void Test_0 () {
	var result = BITCOUNT.bitcount (127);
    Assert.That (result, Is.EqualTo (7));
  }

  [Test]
  public void Test_1 () {
	var result = BITCOUNT.bitcount (128);
    Assert.That (result, Is.EqualTo (1));
  }

  [Test]
  public void Test_2 () {
	var result = BITCOUNT.bitcount (3005);
    Assert.That (result, Is.EqualTo (9));
  }

  [Test]
  public void Test_3 () {
    var result = BITCOUNT.bitcount (13);
    Assert.That (result, Is.EqualTo (3));
  }

  [Test]
  public void Test_4 () {
    var result = BITCOUNT.bitcount (14);
    Assert.That (result, Is.EqualTo (3));
  }

  [Test]
  public void Test_5 () {
    var result = BITCOUNT.bitcount (27);
    Assert.That (result, Is.EqualTo (4));
  }

  [Test]
  public void Test_6 () {
    var result = BITCOUNT.bitcount (834);
    Assert.That (result, Is.EqualTo (4));
  }

  [Test]
  public void Test_7 () {
    var result = BITCOUNT.bitcount (254);
    Assert.That (result, Is.EqualTo (7));
  }

  [Test]
  public void Test_8 () {
    var result = BITCOUNT.bitcount (256);
    Assert.That (result, Is.EqualTo (1));
  }
}

//<ProductionCodeSection>

/**
 *
 * @author derricklin
 */
public class BITCOUNT {
    public static int bitcount(int n) {
    int count = 0;
    while (n != 0) {
        n = (n ^ (n - 1));
        count++;
    }
    return count;
    }
}

//<CorrectSolutionSection>

/**
 *
 * @author derricklin
 */
public class BITCOUNT {
    public static int bitcount(int n) {
    int count = 0;
    while (n != 0) {
        n = (n & (n - 1));
        count++;
    }
    return count;
    }
}
