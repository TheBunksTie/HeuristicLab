//<PassingTestsSection>
Test_0, Test_2, Test_3, Test_4, Test_5

//<FailingTestsSection>
Test_1, Test_6 

//<BestKnownQualitySection>
25

//<CorrectnessSpecificationSection>

[TestFixture, Timeout (3000), SingleThreaded, NonParallelizable]
  public class FIND_IN_SORTED_TEST {

    [Test]
    public void Test_0 () {
      int result = FIND_IN_SORTED.find_in_sorted (new int[] { 3, 4, 5, 5, 5, 5, 6 }, (int) 5);
      Assert.That (result, Is.EqualTo (3));
    }

    [Test]
    public void Test_1 () {
      int result = FIND_IN_SORTED.find_in_sorted (new int[] { 1, 2, 3, 4, 6, 7, 8 }, (int) 5);
      Assert.That (result, Is.EqualTo (-1));
    }

    [Test]
    public void Test_2 () {
      int result = FIND_IN_SORTED.find_in_sorted (new int[] { 1, 2, 3, 4, 6, 7, 8 }, (int) 4);
      Assert.That (result, Is.EqualTo (3));
    }

    [Test]
    public void Test_3 () {
      int result = FIND_IN_SORTED.find_in_sorted (new int[] { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20 }, (int) 18);
      Assert.That (result, Is.EqualTo (8));
    }

    [Test]
    public void Test_4 () {
      int result = FIND_IN_SORTED.find_in_sorted (new int[] { 3, 5, 6, 7, 8, 9, 12, 13, 14, 24, 26, 27 }, (int) 0);
      Assert.That (result, Is.EqualTo (-1));
    }

    [Test]
    public void Test_5 () {
      int result = FIND_IN_SORTED.find_in_sorted (new int[] { 3, 5, 6, 7, 8, 9, 12, 12, 14, 24, 26, 27 }, (int) 12);
      Assert.That (result, Is.EqualTo (6));
    }

    [Test]
    public void Test_6 () {
      int result = FIND_IN_SORTED.find_in_sorted (new int[] { 24, 26, 28, 50, 59 }, (int) 101);
      Assert.That (result, Is.EqualTo (-1));
    }
  }

//<ProductionCodeSection>

  /**
 *
 * @author derricklin
 */
  public class FIND_IN_SORTED {
    public static int binsearch (int[] arr, int x, int start, int end) {
      if (start == end) {
        return -1;
      }
      int mid = start + (end - start) / 2; // check this is floor division
      if (x < arr[mid]) {
        return binsearch (arr, x, start, mid);
      } else if (x > arr[mid]) {
        return binsearch (arr, x, mid /*solution: mid + 1*/, end);
      } else {
        return mid;
      }
    }

    public static int find_in_sorted (int[] arr, int x) {
      return binsearch (arr, x, 0, arr.Length);
    }
  }

//<CorrectSolutionSection>  

  /**
 *
 * @author derricklin
 */
  public class FIND_IN_SORTED {
    public static int binsearch (int[] arr, int x, int start, int end) {
      if (start == end) {
        return -1;
      }
      int mid = start + (end - start) / 2; // check this is floor division
      if (x < arr[mid]) {
        return binsearch (arr, x, start, mid);
      } else if (x > arr[mid]) {
        return binsearch (arr, x, mid + 1, end);
      } else {
        return mid;
      }
    }

    public static int find_in_sorted (int[] arr, int x) {
      return binsearch (arr, x, 0, arr.Length);
    }
  }
