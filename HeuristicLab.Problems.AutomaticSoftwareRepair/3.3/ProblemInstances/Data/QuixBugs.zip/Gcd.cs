//<PassingTestsSection>
-
//<FailingTestsSection>
Test_0, Test_1, Test_2, Test_3, Test_4 

//<BestKnownQualitySection>
50

//<CorrectnessSpecificationSection>

 [TestFixture, Timeout (1000), SingleThreaded, NonParallelizable]
  public class GCD_TEST {

    [Test]
    public void Test_0() {
      int result = GCD.gcd (13, 13);
      Assert.That (result, Is.EqualTo (13));
    }

    [Test]
    public void Test_1() {
      int result = GCD.gcd (37, 600);
      Assert.That (result, Is.EqualTo (1));
    }

    [Test]
    public void Test_2() {
      int result = GCD.gcd (20, 100);
      Assert.That (result, Is.EqualTo (20));
    }

    [Test]
    public void Test_3() {
      int result = GCD.gcd (624129, 2061517);
      Assert.That (result, Is.EqualTo (18913));
    }

    [Test]
    public void Test_4() {
      int result = GCD.gcd (3, 12);
      Assert.That (result, Is.EqualTo (3));
    }
  }

//<ProductionCodeSection>

public class GCD {

    public static int gcd(int a, int b) {
      if (b == 0) {
        return a;
      } else {
        return gcd(a % b, b);
      }
    }
  }

//<CorrectSolutionSection>  

/**
 *
 * @author derricklin
 */
public class GCD {

    public static int gcd(int a, int b) {
        if (b == 0) {
            return a;
        } else {
            return gcd(b, a%b);
        }
    }
}