//<PassingTestsSection>
Test_0, Test_1, Test_2, Test_3,

//<FailingTestsSection>
Test_4,

//<BestKnownQualitySection>
14

//<CorrectnessSpecificationSection>

  [TestFixture, Timeout (1000), SingleThreaded, NonParallelizable]
  public class DEPTH_FIRST_SEARCH_TEST {

	/**
	 * Case 1: Strongly connected graph Output: Path found!
	 */
	[Test]
	public void Test_0() {
		Node station1 = new Node("Westminster");
		Node station2 = new Node("Waterloo", new List<Node>(new [] {station1}));
		Node station3 = new Node("Trafalgar Square", new List<Node>(new [] {station1, station2}));
		Node station4 = new Node("Canary Wharf", new List<Node>(new [] {station2, station3}));
		Node station5 = new Node("London Bridge", new List<Node>(new [] {station4, station3}));
		Node station6 = new Node("Tottenham Court Road", new List<Node>(new [] {station5, station4}));

		Boolean result = new DEPTH_FIRST_SEARCH().depth_first_search(station6, station1);

	  Assert.That(result, Is.True);
	}

	/**
	 * Case 2: Branching graph Output: Path found!
	 */
	[Test]
	public void Test_1() {
	  Node nodef = new Node("F");
	  Node nodee = new Node("E");
	  Node noded = new Node("D");
	  Node nodec = new Node("C", new List<Node>(new [] {nodef}));
	  Node nodeb = new Node("B", new List<Node>(new [] {nodee}));
	  Node nodea = new Node("A", new List<Node>(new [] {nodeb, nodec, noded}));

		Boolean result = new DEPTH_FIRST_SEARCH().depth_first_search(nodea, nodee);

	  Assert.That(result, Is.True);
	}

	/**
	 * Case 3: Two unconnected nodes in graph Output: Path not found
	 */
	[Test]
	public void Test_2() {
	  Node nodef = new Node("F");
	  Node nodee = new Node("E");
	  Node noded = new Node("D");
	  Node nodec = new Node("C", new List<Node>(new [] {nodef}));
	  Node nodeb = new Node("B", new List<Node>(new [] {nodee}));
	  Node nodea = new Node("A", new List<Node>(new [] {nodeb, nodec, noded}));

		Boolean result = new DEPTH_FIRST_SEARCH().depth_first_search(nodef, nodee);

	  Assert.That(result, Is.False);
	}

	/**
	 * Case 4: One node graph Output: Path found
	 */
	[Test]
	public void Test_3() {
	  Node nodef = new Node("F");
	  Node nodee = new Node("E");
	  Node noded = new Node("D");
	  Node nodec = new Node("C", new List<Node>(new [] {nodef}));
	  Node nodeb = new Node("B", new List<Node>(new [] {nodee}));
	  Node nodea = new Node("A", new List<Node>(new [] {nodeb, nodec, noded}));

		Boolean result = new DEPTH_FIRST_SEARCH().depth_first_search(nodef, nodef);

	  Assert.That(result, Is.True);
	}

	/**
	 * Case 5: Graph with cycles Output: Path not found
	 */
	[Test, Timeout(10)]
	public void Test_4() {
	  Node nodef = new Node("F");
	  Node nodee = new Node("E");
	  Node noded = new Node("D");
	  Node nodec = new Node("C", new List<Node>(new [] {nodef}));
	  Node nodeb = new Node("B", new List<Node>(new [] {nodee}));
	  Node nodea = new Node("A", new List<Node>(new [] {nodeb, nodec, noded}));

	  nodee.setSuccessors (new List<Node> (new[] { nodea }));

		Boolean result = new DEPTH_FIRST_SEARCH().depth_first_search(nodea, nodef);
	  Assert.That(result, Is.True);
	} 
}

//<ProductionCodeSection>
 
    /**
   *
   * @author derricklin
   */
  public class DEPTH_FIRST_SEARCH {
    public bool depth_first_search(Node startnode, Node goalnode) {
      HashSet<Node> nodesvisited = new HashSet<Node>();

      Search s = new Search();
      return s.search(startnode, goalnode, nodesvisited);
    }

    class Search {
      public bool search(Node node, Node goalnode, HashSet<Node> nodesvisited) {
        if (nodesvisited.Contains(node)) {
          return false;
        } else if (node == goalnode) {
          return true;
        } else {
          //solution: nodesvisited.Add(node);
          foreach (Node successornodes in node.getSuccessors()) {
            if (search(successornodes, goalnode, nodesvisited)) { return true; }
          }
        }
        return false;
      }
    }
  }

public class Node {

    private String value;
    private List<Node> successors;
    private List<Node> predecessors;
    private Node successor;

    public Node() {
        this.successor = null;
        this.successors = new List<Node>();
        this.predecessors = new List<Node>();
        this.value = null;
    }

    public Node(String value) {
        this.value = value;
        this.successor = null;
        this.successors = new List<Node>();
        this.predecessors = new List<Node>();
    }

    public Node(String value, Node successor) {
        this.value = value;
        this.successor = successor;
    }

    public Node(String value, List<Node> successors) {
        this.value = value;
        this.successors = successors;
    }

    public Node(String value, List<Node> predecessors, List<Node> successors) {
        this.value = value;
        this.predecessors = predecessors;
        this.successors = successors;
    }

    public String getValue() {
        return value;
    }

    public void setSuccessor(Node successor) {
        this.successor = successor;
    }

    public void setSuccessors(List<Node> successors) {
        this.successors = successors;
    }

    public void setPredecessors(List<Node> predecessors) {
    	this.predecessors = predecessors;
    }

    public Node getSuccessor() {
        return successor;
    }

    public List<Node> getSuccessors() {
        return successors;
    }
    public List<Node> getPredecessors() {
        return predecessors;
    }
}

//<CorrectSolutionSection>

  /**
   *
   * @author derricklin
   */
  public class DEPTH_FIRST_SEARCH {
    public bool depth_first_search(Node startnode, Node goalnode) {
      HashSet<Node> nodesvisited = new HashSet<Node>();

      Search s = new Search();
      return s.search(startnode, goalnode, nodesvisited);
    }

    class Search {
      public bool search(Node node, Node goalnode, HashSet<Node> nodesvisited) {
        if (nodesvisited.Contains(node)) {
          return false;
        } else if (node == goalnode) {
          return true;
        } else {
          nodesvisited.Add(node);
          foreach (Node successornodes in node.getSuccessors()) {
            if (search(successornodes, goalnode, nodesvisited)) { return true; }
          }
        }
        return false;
      }
    }
  }

public class Node {

    private String value;
    private List<Node> successors;
    private List<Node> predecessors;
    private Node successor;

    public Node() {
        this.successor = null;
        this.successors = new List<Node>();
        this.predecessors = new List<Node>();
        this.value = null;
    }

    public Node(String value) {
        this.value = value;
        this.successor = null;
        this.successors = new List<Node>();
        this.predecessors = new List<Node>();
    }

    public Node(String value, Node successor) {
        this.value = value;
        this.successor = successor;
    }

    public Node(String value, List<Node> successors) {
        this.value = value;
        this.successors = successors;
    }

    public Node(String value, List<Node> predecessors, List<Node> successors) {
        this.value = value;
        this.predecessors = predecessors;
        this.successors = successors;
    }

    public String getValue() {
        return value;
    }

    public void setSuccessor(Node successor) {
        this.successor = successor;
    }

    public void setSuccessors(List<Node> successors) {
        this.successors = successors;
    }

    public void setPredecessors(List<Node> predecessors) {
    	this.predecessors = predecessors;
    }

    public Node getSuccessor() {
        return successor;
    }

    public List<Node> getSuccessors() {
        return successors;
    }
    public List<Node> getPredecessors() {
        return predecessors;
    }
}