//<PassingTestsSection>
Test_0, Test_1, Test_3, Test_4,

//<FailingTestsSection>
Test_2,

//<BestKnownQualitySection>
14

//<CorrectnessSpecificationSection>

[TestFixture, Timeout (1000), SingleThreaded, NonParallelizable]
public class BREADTH_FIRST_SEARCH_TEST {

  /**
   * Case 1: Strongly connected graph Output: Path found!
   */

  [Test]
  public void Test_0 () {
    Node station1 = new Node ("Westminster");
    Node station2 = new Node ("Waterloo", new List<Node> (new[] { station1 }));
    Node station3 = new Node ("Trafalgar Square", new List<Node> (new List<Node> (new[] { station1, station2 })));
    Node station4 = new Node ("Canary Wharf", new List<Node> (new List<Node> (new[] { station2, station3 })));
    Node station5 = new Node ("London Bridge", new List<Node> (new List<Node> (new[] { station4, station3 })));
    Node station6 = new Node ("Tottenham Court Road", new List<Node> (new List<Node> (new[] { station5, station4 })));
    Boolean result = BREADTH_FIRST_SEARCH.breadth_first_search (station6, station1);

    Assert.That (result, Is.True);
  }

  /**
   * Case 2: Branching graph Output: Path found!
   */
  [Test]
  public void Test_1 () {
    Node nodef = new Node ("F");
    Node nodee = new Node ("E");
    Node noded = new Node ("D");
    Node nodec = new Node ("C", new List<Node> (new List<Node> (new[] { nodef })));
    Node nodeb = new Node ("B", new List<Node> (new List<Node> (new[] { nodee })));
    Node nodea = new Node ("A", new List<Node> (new List<Node> (new[] { nodeb, nodec, noded })));
    Boolean result = BREADTH_FIRST_SEARCH.breadth_first_search (nodea, nodee);

    Assert.That (result, Is.True);
  }

  /**
   * Case 3: Two unconnected nodes in graph Output: Path not found!
   */
  [Test]
  public void Test_2 () {
    Node nodef = new Node ("F");
    Node nodee = new Node ("E");
    Node noded = new Node ("D");
    Node nodec = new Node ("C", new List<Node> (new List<Node> (new[] { nodef })));
    Node nodeb = new Node ("B", new List<Node> (new List<Node> (new[] { nodee })));
    Node nodea = new Node ("A", new List<Node> (new List<Node> (new[] { nodeb, nodec, noded })));

    Boolean result = BREADTH_FIRST_SEARCH.breadth_first_search (nodef, nodee);
    Assert.That (result, Is.False);
  }

  /**
   * Case 4: One node graph Output: Path found!
   */
  [Test]
  public void Test_3 () {
    List<Node> empty = new List<Node>();
    Node nodef = new Node ("F");

    Boolean result = BREADTH_FIRST_SEARCH.breadth_first_search (nodef, nodef);
    Assert.That (result, Is.True);
  }

  /**
   * Case 5: Graph with cycles Output: Path found!
   */

  [Test]
  public void Test_4 () {
    Node node1 = new Node ("1");
    Node node2 = new Node ("2");
    Node node3 = new Node ("3");
    Node node4 = new Node ("4", new List<Node> (new List<Node> (new[] { node1 })));
    Node node5 = new Node ("5", new List<Node> (new List<Node> (new[] { node2 })));
    Node node6 = new Node ("6", new List<Node> (new List<Node> (new[] { node5, node4, node3 })));

    Boolean result = BREADTH_FIRST_SEARCH.breadth_first_search (node6, node1);
    Assert.That (result, Is.True);
  }
}

//<ProductionCodeSection>

 
  public class BREADTH_FIRST_SEARCH {

    public static HashSet<Node> nodesvisited = new HashSet<Node>();

    public static bool breadth_first_search (Node startnode, Node goalnode) {
      var queue = new Queue<Node>();
      queue.Enqueue (startnode);

      nodesvisited.Add (startnode);

      // solution: while (queue.Count > 0) {
      while (true) {
        Node node = queue.Dequeue();

        if (node == goalnode) {
          return true;
        } else {
          foreach (Node successor_node in node.getSuccessors()) {
            if (!nodesvisited.Contains (successor_node)) {
              queue.Enqueue (successor_node);
              nodesvisited.Add (successor_node);
            }
          }
        }
      }
      return false;
    }
  }

public class Node {

    private String value;
    private List<Node> successors;
    private List<Node> predecessors;
    private Node successor;

    public Node() {
        this.successor = null;
        this.successors = new List<Node>();
        this.predecessors = new List<Node>();
        this.value = null;
    }

    public Node(String value) {
        this.value = value;
        this.successor = null;
        this.successors = new List<Node>();
        this.predecessors = new List<Node>();
    }

    public Node(String value, Node successor) {
        this.value = value;
        this.successor = successor;
    }

    public Node(String value, List<Node> successors) {
        this.value = value;
        this.successors = successors;
    }

    public Node(String value, List<Node> predecessors, List<Node> successors) {
        this.value = value;
        this.predecessors = predecessors;
        this.successors = successors;
    }

    public String getValue() {
        return value;
    }

    public void setSuccessor(Node successor) {
        this.successor = successor;
    }

    public void setSuccessors(List<Node> successors) {
        this.successors = successors;
    }

    public void setPredecessors(List<Node> predecessors) {
    	this.predecessors = predecessors;
    }

    public Node getSuccessor() {
        return successor;
    }

    public List<Node> getSuccessors() {
        return successors;
    }
    public List<Node> getPredecessors() {
        return predecessors;
    }
}