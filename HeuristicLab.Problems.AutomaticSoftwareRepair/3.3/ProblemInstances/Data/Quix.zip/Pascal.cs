//<PassingTestsSection>
Test_0

//<FailingTestsSection>
Test_1, Test_2, Test_3, Test_4

//<BestKnownQualitySection>
41

//<CorrectnessSpecificationSection>

 [TestFixture, Timeout (1000), SingleThreaded, NonParallelizable]
  public class PASCAL_TEST {
    [Test]
    public void Test_0() {
      var result = PASCAL.pascal (1);
      Assert.That (result, Is.EqualTo (new List<List<int>> { new List<int> { 1 } }));
    }

  [Test]
  public void Test_1()  {
    var result = PASCAL.pascal (2);
    Assert.That (result, Is.EqualTo (new List<List<int>> { new List<int> { 1 }, new List<int> { 1, 1 } }));
  }

  [Test]
  public void Test_2()  {
    var result = PASCAL.pascal (3);
    Assert.That (result, Is.EqualTo (new List<List<int>> { new List<int> { 1 }, new List<int> { 1, 1 }, new List<int> { 1, 2, 1 } }));
  }

  [Test]
  public void Test_3() {
    var result = PASCAL.pascal (4);
    Assert.That (result, Is.EqualTo (new List<List<int>> { new List<int> { 1 }, new List<int> { 1, 1 }, new List<int> { 1, 2, 1 }, new List<int>{1, 3, 3, 1} }));
  }

  [Test]
  public void Test_4()  {
    var result = PASCAL.pascal (5);
    Assert.That (result, Is.EqualTo (new List<List<int>> { new List<int> { 1 }, new List<int> { 1, 1 }, new List<int> { 1, 2, 1 }, new List<int>{1,3,3,1}, new List<int> {1, 4, 6, 4, 1} }));
  }
}

//<ProductionCodeSection>
  /**
   *
   * @author derricklin
   */
  public class PASCAL {
    public static List<List<int>> pascal(int n) {
      List<List<int>> rows = new List<List<int>>();
      List<int> init = new List<int>();
      init.Add(1);
      rows.Add(init);

      for (int r=1; r<n; r++) {
        List<int> row = new List<int>();
        for (int c=0; c<r; c++) {
          int upleft, upright;
          if (c > 0) {
            upleft = rows[r-1][c-1];
          } else {
            upleft = 0;
          }
          if (c < r) {
            upright = rows[r-1][c];
          } else {
            upright = 0;
          }
          row.Add(upleft+upright);
        }
        rows.Add(row);
      }

      return rows;
    }
  }


//<CorrectSolutionSection>  
  /**
   *
   * @author derricklin
   */
  public class PASCAL {
    public static List<List<int>> pascal(int n) {
      List<List<int>> rows = new List<List<int>>();
      List<int> init = new List<int>();
      init.Add(1);
      rows.Add(init);

      for (int r=1; r<n; r++) {
        List<int> row = new List<int>();
        for (int c=0; c<r+1; c++) {
          int upleft, upright;
          if (c > 0) {
            upleft = rows[r-1][c-1];
          } else {
            upleft = 0;
          }
          if (c < r) {
            upright = rows[r-1][c];
          } else {
            upright = 0;
          }
          row.Add(upleft+upright);
        }
        rows.Add(row);
      }

      return rows;
    }
  }
