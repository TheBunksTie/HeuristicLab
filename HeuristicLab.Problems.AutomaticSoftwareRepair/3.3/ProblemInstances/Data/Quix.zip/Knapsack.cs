//<PassingTestsSection>
Test_0, Test_2, Test_8, Test_9

//<FailingTestsSection>
Test_1, Test_3, Test_4, Test_5, Test_6, Test_7 

//<BestKnownQualitySection>
64

//<CorrectnessSpecificationSection>

   [TestFixture, Timeout (1000), SingleThreaded, NonParallelizable]
  public class KNAPSACK_TEST {
    [Test]
    public void Test_0() {
      var result = KNAPSACK.knapsack (
          100,
          new[] { new[] { 60, 10 }, new[] { 50, 8 }, new[] { 20, 4 }, new[] { 20, 4 }, new[] { 8, 3 }, new[] { 3, 2 } });
      Assert.That (result, Is.EqualTo (19));
    }

    [Test]
    public void Test_1() {
      var result = KNAPSACK.knapsack (40, new[] { new[] { 30, 10 }, new[] { 50, 5 }, new[] { 10, 20 }, new[] { 40, 25 } });
      Assert.That (result, Is.EqualTo (30));
    }

    [Test]
   public void Test_2() {
      var result = KNAPSACK.knapsack (
          750,
          new[] {
                    new[] { 70, 135 }, new[] { 73, 139 }, new[] { 77, 149 }, new[] { 80, 150 }, new[] { 82, 156 }, new[] { 87, 163 },
                    new[] { 90, 173 }, new[] { 94, 184 }, new[] { 98, 192 },
                    new[] { 106, 201 }, new[] { 110, 210 }, new[] { 113, 214 }, new[] { 115, 221 }, new[] { 118, 229 }, new[] { 120, 240 }
                });
      Assert.That (result, Is.EqualTo (1458));
    }

    [Test]
    public void Test_3() {
      var result = KNAPSACK.knapsack (26, new[] { new[] { 12, 24 }, new[] { 7, 13 }, new[] { 11, 23 }, new[] { 8, 15 }, new[] { 9, 16 } });
      Assert.That (result, Is.EqualTo (51));
    }

    [Test]
    public void Test_4() {
      var result = KNAPSACK.knapsack (
          50,
          new[] { new[] { 31, 70 }, new[] { 10, 20 }, new[] { 20, 39 }, new[] { 19, 37 }, new[] { 4, 7 }, new[] { 3, 5 }, new[] { 6, 10 } });
      Assert.That (result, Is.EqualTo (107));
    }

    [Test]
    public void Test_5() {
      var result = KNAPSACK.knapsack (
          190,
          new[] { new[] { 56, 50 }, new[] { 59, 50 }, new[] { 80, 64 }, new[] { 64, 46 }, new[] { 75, 50 }, new[] { 17, 5 } });
      Assert.That (result, Is.EqualTo (150));
    }

    [Test]
    public void Test_6() {
      var result = KNAPSACK.knapsack (
          104,
          new[] {
                    new[] { 25, 350 }, new[] { 35, 400 }, new[] { 45, 450 }, new[] { 5, 20 }, new[] { 25, 70 }, new[] { 3, 8 }, new[] { 2, 5 },
                    new[] { 2, 5 }
                });
      Assert.That (result, Is.EqualTo (900));
    }

    [Test]
    public void Test_7() {
      var result = KNAPSACK.knapsack (
          165,
          new[] {
                    new[] { 23, 92 }, new[] { 31, 57 }, new[] { 29, 49 }, new[] { 44, 68 }, new[] { 53, 60 }, new[] { 38, 43 }, new[] { 63, 67 },
                    new[] { 85, 84 }, new[] { 89, 87 }, new[] { 82, 72 }
                });
      Assert.That (result, Is.EqualTo (309));
    }

    [Test]
    public void Test_8() {
      var result = KNAPSACK.knapsack (
          170,
          new[] {
                    new[] { 41, 442 }, new[] { 50, 525 }, new[] { 49, 511 }, new[] { 59, 593 }, new[] { 55, 546 }, new[] { 57, 564 },
                    new[] { 60, 617 }
                });
      Assert.That (result, Is.EqualTo (1735));
    }

    [Test, Timeout(5000)]
    public void Test_9() {
      var result = KNAPSACK.knapsack (
          6404180,
          new[] {
                    new[] { 382745, 825594 }, new[] { 799601, 1677009 }, new[] { 909247, 1676628 }, new[] { 729069, 1523970 },
                    new[] { 467902, 943972 }, new[] { 44328, 97426 },
                    new[] { 34610, 69666 }, new[] { 698150, 1296457 }, new[] { 823460, 1679693 }, new[] { 903959, 1902996 },
                    new[] { 853665, 1844992 }, new[] { 551830, 1049289 },
                    new[] { 610856, 1252836 }, new[] { 670702, 1319836 }, new[] { 488960, 953277 }, new[] { 951111, 2067538 },
                    new[] { 323046, 675367 }, new[] { 446298, 853655 },
                    new[] { 931161, 1826027 }, new[] { 31385, 65731 }, new[] { 496951, 901489 }, new[] { 264724, 577243 }, new[] { 224916, 466257 },
                    new[] { 169684, 369261 }
                });
      Assert.That (result, Is.EqualTo (13549094));
    }
}

//<ProductionCodeSection>

/**
 *
 * @author derricklin
 */
  public class KNAPSACK {
    public static int knapsack (int capacity, int[][] items) {
      int weight = 0, value = 0;
      int n = items.Length;
      int[,] memo = new int[n + 1,capacity + 1];

      for (int i = 0; i <= n ; i++)
      {
        if (i - 1 >= 0) {
          weight = items[i - 1][0];
          value = items[i - 1][1];
        }
        for (int j = 0; j <= capacity; j++)
        {
          if (i == 0 || j == 0) {
            memo[i,j] = 0;
          }
          else if (weight<j) {
            memo[i,j] = Math.Max(memo[i - 1,j], value + memo[i - 1,j - weight]);
          }
          else {
            memo[i,j] = memo[i - 1,j];
          }

        }
      }
      return memo[n,capacity];
    }

  }

//<CorrectSolutionSection>  

 /**
 *
 * @author derricklin
 */
  public class KNAPSACK {
    public static int knapsack (int capacity, int[][] items) {
      int weight = 0, value = 0;
      int n = items.Length;
      int[,] memo = new int[n + 1,capacity + 1];

      for (int i = 0; i <= n ; i++)
      {
        if (i - 1 >= 0) {
          weight = items[i - 1][0];
          value = items[i - 1][1];
        }
        for (int j = 0; j <= capacity; j++)
        {
          if (i == 0 || j == 0) {
            memo[i,j] = 0;
          }
          else if (weight<=j) {
            memo[i,j] = Math.Max(memo[i - 1,j], value + memo[i - 1,j - weight]);
          }
          else {
            memo[i,j] = memo[i - 1,j];
          }

        }
      }
      return memo[n,capacity];
    }

  }