//<PassingTestsSection>
Test_1, Test_3, Test_4

//<FailingTestsSection>
Test_0, Test_2, Test_5

//<BestKnownQualitySection>
33

//<CorrectnessSpecificationSection>

  [TestFixture, Timeout (1000), SingleThreaded, NonParallelizable]
  public class RPN_EVAL_TEST {

     [Test]
    public void Test_0() {
      var result = RPN_EVAL.rpn_eval (new object[] { 3.0, 5.0, "+", 2.0, "/" });
      Assert.That (result, Is.EqualTo (4.0).Within (0.0));
    } 

    [Test]
  public void Test_1() {
      var result = RPN_EVAL.rpn_eval (new object[] {2.0, 2.0, "+"});
      Assert.That (result, Is.EqualTo (4.0).Within (0.0));
  }

  [Test]
  public void Test_2() {
    var result = RPN_EVAL.rpn_eval (new object[] {7.0, 4.0, "+", 3.0, "-"});
    Assert.That (result, Is.EqualTo (8.0).Within (0.0));
  }

  [Test]
  public void Test_3() {
    var result = RPN_EVAL.rpn_eval (new object[] {1.0, 2.0, "*", 3.0, 4.0, "*", "+"});
    Assert.That (result, Is.EqualTo (14.0).Within (0.0));
  }

  [Test]
  public void Test_4() {
    var result = RPN_EVAL.rpn_eval (new object[] {5.0, 9.0, 2.0, "*", "+"});
    Assert.That (result, Is.EqualTo (23.0).Within (0.0));
  }

  [Test]
  public void Test_5() {
    var result = RPN_EVAL.rpn_eval (new object[] {5.0, 1.0, 2.0, "+", 4.0, "*", "+", 3.0, "-"});
    Assert.That (result, Is.EqualTo (14.0).Within (0.0));
  }
}

//<ProductionCodeSection>

  /**
 *
 * @author derricklin
 */
  public class RPN_EVAL {
    public static Double rpn_eval(Array tokens) {
      var op = new Dictionary<String, Func<Double, Double, Double>>();
      op.Add("+", (a, b) => a + b); 
      op.Add("-", (a, b) => a - b); 
      op.Add("*", (a, b) => a * b); 
      op.Add("/", (a, b) => a / b); 
	

      Stack stack = new Stack();

      foreach (Object token in tokens) {
        if (token is Double) {
          stack.Push((Double) token);
        } else {
          Double a = (Double) stack.Pop();
          Double b = (Double) stack.Pop();
          Double c = 0.0;
          Func<Double, Double, Double> bin_op = op[(String)token];
          c = bin_op.Invoke(a,b);
          stack.Push(c);
        }
      }

      return (Double) stack.Pop();
    }
  }

//<CorrectSolutionSection>  

  /**
 *
 * @author derricklin
 */
  public class RPN_EVAL {
    public static Double rpn_eval(Array tokens) {
      var op = new Dictionary<String, Func<Double, Double, Double>>();
      op.Add("+", (a, b) => a + b); 
      op.Add("-", (a, b) => a - b); 
      op.Add("*", (a, b) => a * b); 
      op.Add("/", (a, b) => a / b); 
	

      Stack stack = new Stack();

      foreach (Object token in tokens) {
        if (token is Double) {
          stack.Push((Double) token);
        } else {
          Double a = (Double) stack.Pop();
          Double b = (Double) stack.Pop();
          Double c = 0.0;
          Func<Double, Double, Double> bin_op = op[(String)token];
          c = bin_op.Invoke(b,a);
          stack.Push(c);
        }
      }

      return (Double) stack.Pop();
    }
  }
